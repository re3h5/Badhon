
<?php
// Fetch user activity summary
$stmt = $conn->prepare("SELECT * FROM user_activity_view");
$stmt->execute();
$user_activity_summary = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch upcoming events
$stmt = $conn->prepare("SELECT * FROM event_details_view WHERE date >= CURDATE()");
$stmt->execute();
$upcoming_events = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
