
<?php
// Fetch feedback data
$stmt = $conn->prepare("
    SELECT u.user_name AS recipient_name, d.name AS donor_name, f.message 
    FROM user_activity_view u
    JOIN feedback f ON u.donor_id = f.donor_id
    ORDER BY f.created_at DESC
");
$stmt->execute();
$feedback_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
