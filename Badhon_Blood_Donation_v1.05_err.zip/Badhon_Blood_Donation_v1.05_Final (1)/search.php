
<?php
// Search notifications and events
$search_query = $_GET['query'] ?? '';
$stmt = $conn->prepare("
    SELECT * 
    FROM notifications_summary_view 
    WHERE message LIKE :search
    UNION
    SELECT * 
    FROM events_summary_view 
    WHERE event_name LIKE :search OR location LIKE :search
");
$stmt->bindValue(':search', '%' . $search_query . '%', PDO::PARAM_STR);
$stmt->execute();
$search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
