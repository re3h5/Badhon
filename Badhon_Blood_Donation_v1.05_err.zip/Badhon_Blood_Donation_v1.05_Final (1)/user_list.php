
<?php
// Fetch user list with activity summary
$stmt = $conn->prepare("SELECT * FROM user_activity_view");
$stmt->execute();
$user_list_with_activity = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
