
-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    role ENUM('Management', 'Admin', 'Volunteer', 'Member'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Donors Table
CREATE TABLE IF NOT EXISTS donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'),
    contact VARCHAR(20),
    address TEXT,
    dob DATE,
    last_donation_date DATE,
    eligibility_status BOOLEAN DEFAULT TRUE,
    donation_count INT DEFAULT 0,
    user_id INT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Feedback Table
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    recipient_id INT,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Donation History Table
CREATE TABLE IF NOT EXISTS donation_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    donation_date DATE,
    location VARCHAR(255),
    recipient_id INT NULL,
    FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    message TEXT,
    type ENUM('Event', 'Emergency', 'Reminder'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Blood Donation Events Table
CREATE TABLE IF NOT EXISTS blood_donation_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255),
    location TEXT,
    date DATE,
    description TEXT,
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Error Logs Table
CREATE TABLE IF NOT EXISTS error_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    error_message TEXT,
    file VARCHAR(255),
    line_number INT,
    resolved BOOLEAN DEFAULT FALSE
);

-- View for Donor Feedback
CREATE OR REPLACE VIEW donor_feedback_view AS
SELECT 
    f.id AS feedback_id,
    f.message,
    f.created_at AS feedback_date,
    d.name AS donor_name,
    u.name AS recipient_name,
    d.blood_group,
    d.last_donation_date
FROM 
    feedback f
JOIN 
    donors d ON f.donor_id = d.id
JOIN 
    users u ON f.recipient_id = u.id;

-- View for Leaderboard
CREATE OR REPLACE VIEW leaderboard_view AS
SELECT 
    u.id AS user_id,
    u.name,
    u.role,
    COUNT(d.id) AS total_donations,
    SUM(CASE WHEN d.last_donation_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR) THEN 1 ELSE 0 END) AS donations_this_year
FROM 
    users u
LEFT JOIN 
    donors d ON u.id = d.user_id
GROUP BY 
    u.id;

-- Sample Data for Feedback
INSERT INTO feedback (donor_id, recipient_id, message) 
VALUES 
(1, 2, 'Thank you for your donation!'),
(2, 3, 'Your contribution saved lives!');

-- Sample Data for Donation History
INSERT INTO donation_history (donor_id, donation_date, location) 
VALUES 
(1, '2024-01-15', 'Dhaka'),
(2, '2024-02-10', 'Rajshahi');
