
-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    role ENUM('Management', 'Admin', 'Volunteer', 'Member'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Donors Table
CREATE TABLE IF NOT EXISTS donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'),
    contact VARCHAR(20),
    address TEXT,
    dob DATE,
    last_donation_date DATE,
    eligibility_status BOOLEAN DEFAULT TRUE,
    donation_count INT DEFAULT 0,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Feedback Table
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    recipient_id INT,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Donation History Table
CREATE TABLE IF NOT EXISTS donation_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    recipient_id INT,
    donation_date DATE,
    location VARCHAR(255),
    FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    message TEXT,
    type ENUM('Event', 'Emergency', 'Reminder'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Blood Donation Events Table
CREATE TABLE IF NOT EXISTS blood_donation_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255),
    location TEXT,
    date DATE,
    description TEXT,
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Comprehensive Views
-- User Activity View
CREATE OR REPLACE VIEW user_activity_view AS
SELECT 
    u.id AS user_id,
    u.name AS user_name,
    u.role AS user_role,
    d.id AS donor_id,
    d.blood_group,
    COUNT(f.id) AS feedback_count,
    COUNT(dh.id) AS donation_count,
    COUNT(n.id) AS notification_count
FROM 
    users u
LEFT JOIN 
    donors d ON u.id = d.user_id
LEFT JOIN 
    feedback f ON f.donor_id = d.id
LEFT JOIN 
    donation_history dh ON dh.donor_id = d.id
LEFT JOIN 
    notifications n ON n.user_id = u.id
GROUP BY 
    u.id;

-- Event Details View
CREATE OR REPLACE VIEW event_details_view AS
SELECT 
    e.id AS event_id,
    e.event_name,
    e.location,
    e.date,
    e.description,
    u.name AS created_by_name
FROM 
    blood_donation_events e
LEFT JOIN 
    users u ON e.created_by = u.id;

-- Donor Feedback View
CREATE OR REPLACE VIEW donor_feedback_view AS
SELECT 
    d.id AS donor_id,
    d.name AS donor_name,
    d.blood_group,
    u.id AS recipient_id,
    u.name AS recipient_name,
    f.message AS feedback_message,
    f.created_at AS feedback_date
FROM 
    donors d
LEFT JOIN 
    feedback f ON d.id = f.donor_id
LEFT JOIN 
    users u ON f.recipient_id = u.id;

-- Notifications Summary View
CREATE OR REPLACE VIEW notifications_summary_view AS
SELECT 
    n.id AS notification_id,
    n.user_id,
    u.name AS user_name,
    n.message,
    n.type,
    n.created_at AS notification_date
FROM 
    notifications n
LEFT JOIN 
    users u ON n.user_id = u.id;

-- Sample Data for Testing
INSERT INTO users (name, email, password, role) VALUES
('John Doe', 'john.doe@example.com', 'password123', 'Management'),
('Jane Smith', 'jane.smith@example.com', 'password123', 'Admin'),
('Alice Brown', 'alice.brown@example.com', 'password123', 'Volunteer'),
('Bob White', 'bob.white@example.com', 'password123', 'Member');

INSERT INTO donors (name, blood_group, contact, address, dob, last_donation_date, user_id) VALUES
('John Donor', 'A+', '1234567890', '123 Main St', '1985-05-10', '2023-08-10', 1),
('Jane Donor', 'B-', '0987654321', '456 Side St', '1990-02-14', '2023-06-15', 2);
