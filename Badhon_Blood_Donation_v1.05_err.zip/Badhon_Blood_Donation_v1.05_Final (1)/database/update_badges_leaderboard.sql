
ALTER TABLE donors ADD COLUMN badges JSON NULL;
ALTER TABLE users ADD COLUMN leaderboard_points INT DEFAULT 0;

DELIMITER $$

CREATE PROCEDURE UpdateBadgesAndPoints()
BEGIN
    -- Update badges based on donation count
    UPDATE donors
    SET badges = JSON_OBJECT(
        'gold', (donation_count >= 20),
        'silver', (donation_count >= 10 AND donation_count < 20),
        'bronze', (donation_count >= 5 AND donation_count < 10)
    );

    -- Update leaderboard points
    UPDATE users
    SET leaderboard_points = (
        SELECT SUM(
            CASE role
                WHEN 'Volunteer' THEN 5
                WHEN 'Admin' THEN 2
                ELSE 10
            END
        )
        FROM users u
        WHERE u.id = users.id
    );
END$$

DELIMITER ;
