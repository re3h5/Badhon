
-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255),
    role ENUM('Management', 'Admin', 'Volunteer', 'Member'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Donors Table
CREATE TABLE IF NOT EXISTS donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'),
    contact VARCHAR(20),
    address TEXT,
    dob DATE,
    last_donation_date DATE,
    eligibility_status BOOLEAN DEFAULT TRUE,
    donation_count INT DEFAULT 0,
    user_id INT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Feedback Table
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    recipient_id INT,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Donation History Table
CREATE TABLE IF NOT EXISTS donation_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    donation_date DATE,
    location VARCHAR(255),
    recipient_id INT NULL,
    FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    message TEXT,
    type ENUM('Event', 'Emergency', 'Reminder'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Blood Donation Events Table
CREATE TABLE IF NOT EXISTS blood_donation_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255),
    location TEXT,
    date DATE,
    description TEXT,
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Error Logs Table
CREATE TABLE IF NOT EXISTS error_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    error_message TEXT,
    file VARCHAR(255),
    line_number INT,
    resolved BOOLEAN DEFAULT FALSE
);

-- View for Donor Feedback
CREATE OR REPLACE VIEW donor_feedback_view AS
SELECT 
    f.id AS feedback_id,
    f.message,
    f.created_at AS feedback_date,
    d.name AS donor_name,
    u.name AS recipient_name,
    d.blood_group,
    d.last_donation_date
FROM 
    feedback f
JOIN 
    donors d ON f.donor_id = d.id
JOIN 
    users u ON f.recipient_id = u.id;

-- View for Leaderboard
CREATE OR REPLACE VIEW leaderboard_view AS
SELECT 
    u.id AS user_id,
    u.name,
    u.role,
    COUNT(d.id) AS total_donations,
    SUM(CASE WHEN d.last_donation_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR) THEN 1 ELSE 0 END) AS donations_this_year
FROM 
    users u
LEFT JOIN 
    donors d ON u.id = d.user_id
GROUP BY 
    u.id;

-- Sample Data for Feedback
INSERT INTO feedback (donor_id, recipient_id, message) 
VALUES 
(1, 2, 'Thank you for your donation!'),
(2, 3, 'Your contribution saved lives!');

-- Sample Data for Donation History
INSERT INTO donation_history (donor_id, donation_date, location) 
VALUES 
(1, '2024-01-15', 'Dhaka'),
(2, '2024-02-10', 'Rajshahi');


-- View: Donor Feedback
CREATE OR REPLACE VIEW donor_feedback_view AS
SELECT 
    d.id AS donor_id,
    d.name AS donor_name,
    d.blood_group,
    u.id AS recipient_id,
    u.name AS recipient_name,
    f.message AS feedback_message,
    f.created_at AS feedback_date
FROM 
    donors d
LEFT JOIN 
    feedback f ON d.id = f.donor_id
LEFT JOIN 
    users u ON f.recipient_id = u.id;

-- View: Donation Activity
CREATE OR REPLACE VIEW donation_activity_view AS
SELECT 
    dh.id AS activity_id,
    d.name AS donor_name,
    d.blood_group,
    u.name AS recipient_name,
    dh.donation_date,
    dh.location
FROM 
    donation_history dh
LEFT JOIN 
    donors d ON dh.donor_id = d.id
LEFT JOIN 
    users u ON dh.recipient_id = u.id;

-- View: Leaderboard
CREATE OR REPLACE VIEW leaderboard_view AS
SELECT 
    u.id AS user_id,
    u.name,
    u.role,
    COUNT(dh.id) AS total_donations,
    MAX(dh.donation_date) AS last_donation_date
FROM 
    users u
LEFT JOIN 
    donors d ON u.id = d.user_id
LEFT JOIN 
    donation_history dh ON d.id = dh.donor_id
GROUP BY 
    u.id;


-- View: Notifications Summary
CREATE OR REPLACE VIEW notifications_summary_view AS
SELECT 
    n.id AS notification_id,
    n.user_id,
    u.name AS user_name,
    n.message,
    n.type,
    n.created_at AS notification_date
FROM 
    notifications n
LEFT JOIN 
    users u ON n.user_id = u.id;

-- View: Events Summary
CREATE OR REPLACE VIEW events_summary_view AS
SELECT 
    e.id AS event_id,
    e.event_name,
    e.location,
    e.date,
    e.description,
    u.name AS created_by_name
FROM 
    blood_donation_events e
LEFT JOIN 
    users u ON e.created_by = u.id;


-- View: Comprehensive User Activity
CREATE OR REPLACE VIEW user_activity_view AS
SELECT 
    u.id AS user_id,
    u.name AS user_name,
    u.role AS user_role,
    d.id AS donor_id,
    d.blood_group,
    COUNT(f.id) AS feedback_count,
    COUNT(dh.id) AS donation_count,
    COUNT(n.id) AS notification_count
FROM 
    users u
LEFT JOIN 
    donors d ON u.id = d.user_id
LEFT JOIN 
    feedback f ON f.donor_id = d.id
LEFT JOIN 
    donation_history dh ON dh.donor_id = d.id
LEFT JOIN 
    notifications n ON n.user_id = u.id
GROUP BY 
    u.id;

-- View: Comprehensive Event Details
CREATE OR REPLACE VIEW event_details_view AS
SELECT 
    e.id AS event_id,
    e.event_name,
    e.location,
    e.date,
    e.description,
    u.name AS created_by_name
FROM 
    blood_donation_events e
LEFT JOIN 
    users u ON e.created_by = u.id;
