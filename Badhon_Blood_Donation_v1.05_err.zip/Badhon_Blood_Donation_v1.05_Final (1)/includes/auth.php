<?php
session_start();
require_once 'config.php';

// Login Function
function login($email, $password) {
    global $conn;
    $query = "SELECT * FROM users WHERE email = :email";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        return true;
    }
    return false;
}

// Check Login Status
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Logout Function
function logout() {
    session_unset();
    session_destroy();
    header('Location: ' . SITE_URL . '/index.php');
    exit();
}

// Check Role
function check_role($required_role) {
    if ($_SESSION['role'] !== $required_role) {
        header('Location: ' . SITE_URL . '/403.php');
        exit();
    }
}
?>
