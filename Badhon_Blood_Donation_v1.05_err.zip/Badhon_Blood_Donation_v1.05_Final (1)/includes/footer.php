<?php
    <!-- Footer -->
    <footer class="bg-dark text-light text-center py-4 mt-5">
        <div class="container">
            <p>&copy; 2024 Badhon Blood Donation. All rights reserved.</p>
            <div class="social-links">
                <a href="#" class="text-light mx-2"><i class="fa-brands fa-facebook"></i></a>
                <a href="#" class="text-light mx-2"><i class="fa-brands fa-twitter"></i></a>
                <a href="#" class="text-light mx-2"><i class="fa-brands fa-instagram"></i></a>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>

?>