<?php
// Database Configuration
$host = 'localhost'; // Database host
$db_name = 'badhon_blood_donation'; // Database name
$db_user = 'root'; // Database username
$db_password = ''; // Database password (leave blank for local setup)

// Create a connection
try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $db_user, $db_password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// General Settings
define('SITE_URL', 'http://localhost/Badhon_Blood_Donation');
define('SITE_NAME', 'Badhon Blood Donation');
?>
