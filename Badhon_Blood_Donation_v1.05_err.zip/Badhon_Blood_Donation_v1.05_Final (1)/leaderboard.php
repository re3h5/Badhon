
<?php
// Fetch leaderboard data
$stmt = $conn->prepare("SELECT * FROM user_activity_view ORDER BY donation_count DESC");
$stmt->execute();
$leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
