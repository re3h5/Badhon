
<?php
// Fetch recipient feedback with related donor data
$stmt = $conn->prepare("
    SELECT f.message, d.name AS donor_name, f.created_at AS feedback_date
    FROM feedback f
    LEFT JOIN donors d ON f.donor_id = d.id
    WHERE f.recipient_id = :recipient_id
");
$stmt->bindValue(':recipient_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->execute();
$recipient_feedback = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
