<?php require_once '../includes/config.php'; ?>
<?php include '../includes/header.php'; ?>

<?php
// Fetch analytics data
$analytics = [
    'monthly_donations' => [],
    'blood_group_distribution' => [],
    'fulfilled_requests' => 0,
    'pending_requests' => 0,
];

try {
    // Monthly donations
    $stmt = $conn->prepare("SELECT DATE_FORMAT(last_donation_date, '%Y-%m') AS month, COUNT(*) AS count FROM donors WHERE last_donation_date IS NOT NULL GROUP BY month ORDER BY month DESC LIMIT 6");
    $stmt->execute();
    $analytics['monthly_donations'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Blood group distribution
    $stmt = $conn->prepare("SELECT blood_group, COUNT(*) AS count FROM donors GROUP BY blood_group");
    $stmt->execute();
    $analytics['blood_group_distribution'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fulfilled and pending requests
    $stmt = $conn->prepare("SELECT COUNT(*) AS fulfilled FROM emergency_requests WHERE status = 'Resolved'");
    $stmt->execute();
    $analytics['fulfilled_requests'] = $stmt->fetchColumn();

    $stmt = $conn->prepare("SELECT COUNT(*) AS pending FROM emergency_requests WHERE status = 'Pending'");
    $stmt->execute();
    $analytics['pending_requests'] = $stmt->fetchColumn();
} catch (PDOException $e) {
    die("Error fetching analytics data: " . $e->getMessage());
}
?>

<div class="container my-5">
    <h1 class="text-center">Analytics Dashboard</h1>

    <!-- Fulfilled vs Pending Requests -->
    <div class="my-4">
        <h3>Emergency Requests Overview</h3>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Fulfilled Requests</h5>
                        <p class="display-4"><?php echo $analytics['fulfilled_requests']; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Pending Requests</h5>
                        <p class="display-4"><?php echo $analytics['pending_requests']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Monthly Donations Chart -->
    <div class="my-4">
        <h3>Monthly Donations</h3>
        <canvas id="monthlyDonationsChart" height="100"></canvas>
    </div>

    <!-- Blood Group Distribution Chart -->
    <div class="my-4">
        <h3>Blood Group Distribution</h3>
        <canvas id="bloodGroupChart" height="100"></canvas>
    </div>

    <!-- Export Options -->
    <div class="my-4 text-center">
        <h3>Export Data</h3>
        <a href="export_data.php?type=csv" class="btn btn-primary">Export as CSV</a>
        <a href="export_data.php?type=pdf" class="btn btn-secondary">Export as PDF</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Monthly Donations Chart
    const monthlyDonationsCtx = document.getElementById('monthlyDonationsChart').getContext('2d');
    const monthlyDonationsData = {
        labels: <?php echo json_encode(array_column($analytics['monthly_donations'], 'month')); ?>,
        datasets: [{
            label: 'Donations',
            data: <?php echo json_encode(array_column($analytics['monthly_donations'], 'count')); ?>,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }]
    };
    new Chart(monthlyDonationsCtx, {
        type: 'line',
        data: monthlyDonationsData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            }
        }
    });

    // Blood Group Distribution Chart
    const bloodGroupCtx = document.getElementById('bloodGroupChart').getContext('2d');
    const bloodGroupData = {
        labels: <?php echo json_encode(array_column($analytics['blood_group_distribution'], 'blood_group')); ?>,
        datasets: [{
            label: 'Blood Groups',
            data: <?php echo json_encode(array_column($analytics['blood_group_distribution'], 'count')); ?>,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(201, 203, 207, 0.2)',
                'rgba(123, 233, 165, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(201, 203, 207, 1)',
                'rgba(123, 233, 165, 1)'
            ],
            borderWidth: 1
        }]
    };
    new Chart(bloodGroupCtx, {
        type: 'pie',
        data: bloodGroupData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom'
                }
            }
        }
    });
</script>

<?php include '../includes/footer.php'; ?>
