<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Fetch all volunteers
$volunteers = [];
try {
    $stmt = $conn->prepare("SELECT id, name, email FROM users WHERE role = 'Volunteer'");
    $stmt->execute();
    $volunteers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching volunteers: " . $e->getMessage());
}

// Handle Assign Task or Remove Volunteer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $volunteer_id = $_POST['volunteer_id'];
    $action = $_POST['action'];

    try {
        if ($action === 'assign_task') {
            $task = $_POST['task'];
            $stmt = $conn->prepare("INSERT INTO volunteer_tasks (volunteer_id, task) VALUES (:volunteer_id, :task)");
            $stmt->bindParam(':volunteer_id', $volunteer_id);
            $stmt->bindParam(':task', $task);
            $stmt->execute();
            $message = "Task assigned successfully.";
        } elseif ($action === 'remove') {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = :id");
            $stmt->bindParam(':id', $volunteer_id);
            $stmt->execute();
            $message = "Volunteer removed successfully.";
        }
    } catch (PDOException $e) {
        $error = "Error performing action: " . $e->getMessage();
    }
    header('Location: volunteer_management.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Volunteer Management</h1>
    <?php if (!empty($message)): ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($volunteers as $volunteer): ?>
                <tr>
                    <td><?php echo $volunteer['id']; ?></td>
                    <td><?php echo $volunteer['name']; ?></td>
                    <td><?php echo $volunteer['email']; ?></td>
                    <td>
                        <!-- Assign Task Form -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="volunteer_id" value="<?php echo $volunteer['id']; ?>">
                            <input type="text" name="task" placeholder="Enter Task" class="form-control d-inline w-auto">
                            <button type="submit" name="action" value="assign_task" class="btn btn-primary btn-sm">Assign Task</button>
                        </form>
                        <!-- Remove Volunteer Form -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="volunteer_id" value="<?php echo $volunteer['id']; ?>">
                            <button type="submit" name="action" value="remove" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to remove this volunteer?')">Remove</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>
