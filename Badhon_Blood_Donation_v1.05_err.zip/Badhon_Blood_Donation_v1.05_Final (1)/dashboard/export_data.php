<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['type'])) {
    $type = $_GET['type'];

    try {
        $stmt = $conn->prepare("SELECT name, blood_group, contact, address, last_donation_date FROM donors");
        $stmt->execute();
        $donors = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($type === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="donor_data.csv"');

            $output = fopen('php://output', 'w');
            fputcsv($output, ['Name', 'Blood Group', 'Contact', 'Address', 'Last Donation Date']);

            foreach ($donors as $donor) {
                fputcsv($output, $donor);
            }
            fclose($output);
            exit;
        } elseif ($type === 'pdf') {
            require_once '../vendor/autoload.php';
            $mpdf = new \Mpdf\Mpdf();
            $html = '<h1>Donor Data</h1><table border="1"><thead><tr><th>Name</th><th>Blood Group</th><th>Contact</th><th>Address</th><th>Last Donation Date</th></tr></thead><tbody>';
            foreach ($donors as $donor) {
                $html .= '<tr><td>' . htmlspecialchars($donor['name']) . '</td><td>' . htmlspecialchars($donor['blood_group']) . '</td><td>' . htmlspecialchars($donor['contact']) . '</td><td>' . htmlspecialchars($donor['address']) . '</td><td>' . htmlspecialchars($donor['last_donation_date']) . '</td></tr>';
            }
            $html .= '</tbody></table>';
            $mpdf->WriteHTML($html);
            $mpdf->Output('donor_data.pdf', 'D');
            exit;
        } else {
            die('Invalid export type.');
        }
    } catch (PDOException $e) {
        die('Error fetching donor data: ' . $e->getMessage());
    }
}
?>
