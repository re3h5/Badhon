<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Get Donor ID from URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<div class='container my-5'><div class='alert alert-danger text-center'>Invalid donor ID.</div></div>";
    include '../includes/footer.php';
    exit();
}

$donor_id = intval($_GET['id']);
$user_role = $_SESSION['role'];

// Fetch Donor Details
$donor = [];
try {
    $stmt = $conn->prepare("SELECT * FROM donors WHERE id = :id");
    $stmt->bindParam(':id', $donor_id);
    $stmt->execute();
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$donor) {
        echo "<div class='container my-5'><div class='alert alert-danger text-center'>Donor not found.</div></div>";
        include '../includes/footer.php';
        exit();
    }
} catch (PDOException $e) {
    die("Error fetching donor details: " . $e->getMessage());
}

// Restrict Sensitive Data for Members (Donors)
$sensitive_data_visible = in_array($user_role, ['Volunteer', 'Admin', 'Management']);
?>

<div class="container my-5">
    <h1 class="text-center">Donor Profile</h1>
    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-body">
            <h5 class="card-title"><?php echo $donor['name']; ?></h5>
            <p class="card-text">
                <strong>Blood Group:</strong> <?php echo $donor['blood_group']; ?><br>
                <?php if ($sensitive_data_visible): ?>
                    <strong>Contact:</strong> <?php echo $donor['contact']; ?><br>
                    <strong>Address:</strong> <?php echo $donor['address']; ?><br>
                    <strong>Date of Birth:</strong> <?php echo $donor['dob']; ?><br>
                <?php else: ?>
                    <strong>Contact:</strong> Restricted<br>
                    <strong>Address:</strong> Restricted<br>
                    <strong>Date of Birth:</strong> Restricted<br>
                <?php endif; ?>
                <strong>Last Donation Date:</strong> <?php echo $donor['last_donation_date'] ?: 'No record'; ?><br>
                <strong>Eligibility Status:</strong> <?php echo $donor['eligibility_status'] ? 'Eligible' : 'Not Eligible'; ?>
            </p>
        </div>
    </div>
    <div class="text-center my-4">
        <a href="javascript:history.back()" class="btn btn-secondary">Go Back</a>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
