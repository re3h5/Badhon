
<?php
// Fetch notifications summary
$stmt = $conn->prepare("SELECT * FROM notifications_summary_view ORDER BY notification_date DESC LIMIT 5");
$stmt->execute();
$recent_notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch user activity summary
$stmt = $conn->prepare("SELECT * FROM user_activity_view ORDER BY donation_count DESC LIMIT 5");
$stmt->execute();
$top_donors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch feedback count
$stmt = $conn->prepare("SELECT COUNT(*) AS feedback_count FROM feedback");
$stmt->execute();
$feedback_count = $stmt->fetch(PDO::FETCH_ASSOC)['feedback_count'];

// Fetch donation history count
$stmt = $conn->prepare("SELECT COUNT(*) AS total_donations FROM donation_history");
$stmt->execute();
$total_donations = $stmt->fetch(PDO::FETCH_ASSOC)['total_donations'];
?>
