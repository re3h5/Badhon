<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Member') {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Fetch Member Details
$user_id = $_SESSION['user_id'];
$member_data = [];
try {
    $stmt = $conn->prepare("SELECT * FROM donors WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $member_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching member data: " . $e->getMessage());
}
?>

<div class="container my-5">
    <h1 class="text-center">Personal Data</h1>

    <?php if ($member_data): ?>
        <div class="card mx-auto" style="max-width: 600px;">
            <div class="card-body">
                <h5 class="card-title">Hello, <?php echo $member_data['name']; ?>!</h5>
                <p class="card-text">
                    <strong>Blood Group:</strong> <?php echo $member_data['blood_group']; ?><br>
                    <strong>Contact:</strong> <?php echo $member_data['contact']; ?><br>
                    <strong>Address:</strong> <?php echo $member_data['address']; ?><br>
                    <strong>Last Donation Date:</strong> <?php echo $member_data['last_donation_date'] ?: 'No record'; ?><br>
                    <strong>Eligibility Status:</strong> <?php echo $member_data['eligibility_status'] ? 'Eligible' : 'Not Eligible'; ?>
                </p>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center">
            No personal data found.
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
