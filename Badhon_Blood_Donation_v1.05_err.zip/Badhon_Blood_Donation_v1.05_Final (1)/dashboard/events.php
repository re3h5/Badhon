<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Volunteer') {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Fetch all events managed by this volunteer
$volunteer_id = $_SESSION['user_id'];
$events = [];
try {
    $stmt = $conn->prepare("SELECT * FROM blood_donation_events WHERE created_by = :volunteer_id");
    $stmt->bindParam(':volunteer_id', $volunteer_id);
    $stmt->execute();
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching events: " . $e->getMessage());
}

// Handle Add, Update, or Delete Event
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    try {
        if ($action === 'add') {
            $stmt = $conn->prepare("INSERT INTO blood_donation_events (event_name, location, date, description, created_by)
                                    VALUES (:event_name, :location, :date, :description, :created_by)");
            $stmt->bindParam(':event_name', $_POST['event_name']);
            $stmt->bindParam(':location', $_POST['location']);
            $stmt->bindParam(':date', $_POST['date']);
            $stmt->bindParam(':description', $_POST['description']);
            $stmt->bindParam(':created_by', $volunteer_id);
            $stmt->execute();
            $message = "Event added successfully.";
        } elseif ($action === 'update') {
            $stmt = $conn->prepare("UPDATE blood_donation_events SET event_name = :event_name, location = :location, date = :date, description = :description WHERE id = :id");
            $stmt->bindParam(':event_name', $_POST['event_name']);
            $stmt->bindParam(':location', $_POST['location']);
            $stmt->bindParam(':date', $_POST['date']);
            $stmt->bindParam(':description', $_POST['description']);
            $stmt->bindParam(':id', $_POST['event_id']);
            $stmt->execute();
            $message = "Event updated successfully.";
        } elseif ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM blood_donation_events WHERE id = :id");
            $stmt->bindParam(':id', $_POST['event_id']);
            $stmt->execute();
            $message = "Event deleted successfully.";
        }
    } catch (PDOException $e) {
        $error = "Error performing action: " . $e->getMessage();
    }
    header('Location: events.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Event Management</h1>
    <?php if (!empty($message)): ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Add Event Form -->
    <div class="mb-4">
        <h3>Add New Event</h3>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label for="event_name" class="form-label">Event Name</label>
                <input type="text" name="event_name" id="event_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" name="location" id="location" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="date" class="form-label">Date</label>
                <input type="date" name="date" id="date" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea name="description" id="description" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Add Event</button>
        </form>
    </div>

    <!-- Events List -->
    <h3>Manage Events</h3>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Event Name</th>
                <th>Location</th>
                <th>Date</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($events as $event): ?>
                <tr>
                    <td><?php echo $event['event_name']; ?></td>
                    <td><?php echo $event['location']; ?></td>
                    <td><?php echo $event['date']; ?></td>
                    <td><?php echo $event['description']; ?></td>
                    <td>
                        <!-- Update Event Form -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                            <button type="submit" class="btn btn-warning btn-sm">Edit</button>
                        </form>
                        <!-- Delete Event Form -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this event?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>
