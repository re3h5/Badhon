<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Member') {
    header('Location: ../pages/shared_login.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Member Dashboard</h1>
    <div class="row text-center">
        <div class="col-md-12">
            <a href="personal_data.php" class="btn btn-outline-primary btn-lg w-100">View Personal Data</a>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
