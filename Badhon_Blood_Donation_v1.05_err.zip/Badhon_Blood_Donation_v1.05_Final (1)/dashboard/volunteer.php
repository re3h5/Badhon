<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Volunteer') {
    header('Location: ../pages/shared_login.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Volunteer Dashboard</h1>
    <div class="row text-center">
        <div class="col-md-6">
            <a href="donor_management.php" class="btn btn-outline-primary btn-lg w-100">Manage Donors</a>
        </div>
        <div class="col-md-6">
            <a href="events.php" class="btn btn-outline-success btn-lg w-100">Manage Events</a>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
