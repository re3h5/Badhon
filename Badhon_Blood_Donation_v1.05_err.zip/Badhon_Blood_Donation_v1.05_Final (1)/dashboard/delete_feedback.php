<?php require_once '../includes/config.php'; ?>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    try {
        $stmt = $conn->prepare("DELETE FROM feedback WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        header("Location: feedback_admin.php");
        exit;
    } catch (PDOException $e) {
        die("Error deleting feedback: " . $e->getMessage());
    }
} else {
    header("Location: feedback_admin.php");
    exit;
}
?>
