<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Management') {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Fetch all users
$users = [];
try {
    $stmt = $conn->prepare("SELECT id, name, email, role FROM users WHERE role != 'Management'");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching users: " . $e->getMessage());
}

// Handle Role Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $user_id = $_POST['user_id'];
    $new_role = $_POST['role'];
    $action = $_POST['action'];

    try {
        if ($action === 'update') {
            $stmt = $conn->prepare("UPDATE users SET role = :role WHERE id = :id");
            $stmt->bindParam(':role', $new_role);
            $stmt->bindParam(':id', $user_id);
            $stmt->execute();
            $message = "User role updated successfully.";
        } elseif ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = :id");
            $stmt->bindParam(':id', $user_id);
            $stmt->execute();
            $message = "User deleted successfully.";
        }
    } catch (PDOException $e) {
        $error = "Error performing action: " . $e->getMessage();
    }
    header('Location: role_management.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Role Management</h1>
    <?php if (!empty($message)): ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo $user['name']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td><?php echo $user['role']; ?></td>
                    <td>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <select name="role" class="form-select d-inline w-auto">
                                <option value="Admin" <?php echo $user['role'] === 'Admin' ? 'selected' : ''; ?>>Admin</option>
                                <option value="Volunteer" <?php echo $user['role'] === 'Volunteer' ? 'selected' : ''; ?>>Volunteer</option>
                                <option value="Member" <?php echo $user['role'] === 'Member' ? 'selected' : ''; ?>>Member</option>
                            </select>
                            <button type="submit" name="action" value="update" class="btn btn-primary btn-sm">Update</button>
                        </form>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <button type="submit" name="action" value="delete" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>
