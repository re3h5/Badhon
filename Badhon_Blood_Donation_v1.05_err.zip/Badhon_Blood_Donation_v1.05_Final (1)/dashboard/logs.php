<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Management', 'Admin', 'Volunteer'])) {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Role-based log types
$role = $_SESSION['role'];
$log_types = [];
if ($role === 'Management') {
    $log_types = ['User Management', 'Donor', 'Event', 'Emergency Request', 'Notification', 'Error'];
} elseif ($role === 'Admin') {
    $log_types = ['Volunteer', 'Donor'];
} elseif ($role === 'Volunteer') {
    $log_types = ['Donor', 'Event'];
}

// Fetch logs based on selected type
$type = $_GET['type'] ?? $log_types[0];
$logs = [];
try {
    $query = "SELECT * FROM logs WHERE action_type = :type ORDER BY timestamp DESC";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':type', $type);
    $stmt->execute();
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching logs: " . $e->getMessage());
}
?>

<div class="container my-5">
    <h1 class="text-center">Logs Viewer</h1>

    <!-- Filter Section -->
    <form method="GET" class="mb-4">
        <label for="type">Filter by Type:</label>
        <select name="type" id="type" class="form-select w-auto d-inline-block">
            <?php foreach ($log_types as $log_type): ?>
                <option value="<?php echo $log_type; ?>" <?php echo $type === $log_type ? 'selected' : ''; ?>>
                    <?php echo $log_type; ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
    </form>

    <!-- Logs Table -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Timestamp</th>
                <th>User ID</th>
                <th>Role</th>
                <th>Action Type</th>
                <th>Details</th>
                <th>IP Address</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($logs)): ?>
                <tr>
                    <td colspan="6" class="text-center">No logs found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo $log['timestamp']; ?></td>
                        <td><?php echo $log['user_id']; ?></td>
                        <td><?php echo $log['role']; ?></td>
                        <td><?php echo $log['action_type']; ?></td>
                        <td><?php echo $log['details']; ?></td>
                        <td><?php echo $log['ip_address']; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>
