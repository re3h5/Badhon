<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Fetch Role and User ID
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Handle Send Notification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notification'])) {
    $recipient_role = $_POST['recipient_role'];
    $message = htmlspecialchars($_POST['message']);

    try {
        if ($recipient_role === 'All') {
            // Send to all users
            $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, type) SELECT id, :message, 'General' FROM users");
            $stmt->bindParam(':message', $message);
        } else {
            // Send to specific role
            $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, type) SELECT id, :message, 'General' FROM users WHERE role = :role");
            $stmt->bindParam(':message', $message);
            $stmt->bindParam(':role', $recipient_role);
        }
        $stmt->execute();
        $success_message = "Notification sent successfully!";
    } catch (PDOException $e) {
        $error_message = "Error sending notification: " . $e->getMessage();
    }
}

// Fetch Notifications
$notifications = [];
try {
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching notifications: " . $e->getMessage());
}
?>

<div class="container my-5">
    <h1 class="text-center">Notifications</h1>

    <!-- Send Notification (For Admin and Management) -->
    <?php if (in_array($role, ['Admin', 'Management'])): ?>
        <div class="mb-4">
            <h3>Send Notification</h3>
            <?php if (isset($success_message)): ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
            <?php elseif (isset($error_message)): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="recipient_role" class="form-label">Recipient Role</label>
                    <select name="recipient_role" id="recipient_role" class="form-select" required>
                        <option value="All">All Users</option>
                        <option value="Management">Management</option>
                        <option value="Admin">Admins</option>
                        <option value="Volunteer">Volunteers</option>
                        <option value="Member">Donors</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="message" class="form-label">Message</label>
                    <textarea name="message" id="message" class="form-control" required></textarea>
                </div>
                <button type="submit" name="send_notification" class="btn btn-primary">Send Notification</button>
            </form>
        </div>
    <?php endif; ?>

    <!-- Display Notifications -->
    <h3>Your Notifications</h3>
    <?php if (empty($notifications)): ?>
        <div class="alert alert-info">No notifications available.</div>
    <?php else: ?>
        <ul class="list-group">
            <?php foreach ($notifications as $notification): ?>
                <li class="list-group-item">
                    <p><strong>Message:</strong> <?php echo $notification['message']; ?></p>
                    <p><small><strong>Sent At:</strong> <?php echo $notification['created_at']; ?></small></p>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
