<?php include '../includes/header.php'; ?>

<div class="container my-5">
    <h1 class="text-center">About Us</h1>
    <p class="text-center">
        At Badhon Blood Donation, our mission is to create a network of voluntary blood donors to save lives and support healthcare services across communities.
    </p>

    <!-- Mission Section -->
    <div class="my-4">
        <h3>Our Mission</h3>
        <p>
            We are dedicated to ensuring that every patient has access to safe and timely blood donations. Our efforts focus on building a reliable system where volunteers and donors come together to make a life-saving impact.
        </p>
    </div>

    <!-- Team Section -->
    <div class="my-4">
        <h3>Meet Our Team</h3>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <img src="../assets/images/team1.jpg" class="card-img-top" alt="Team Member">
                    <div class="card-body">
                        <h5 class="card-title">John Doe</h5>
                        <p class="card-text">Founder & Director</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="../assets/images/team2.jpg" class="card-img-top" alt="Team Member">
                    <div class="card-body">
                        <h5 class="card-title">Jane Smith</h5>
                        <p class="card-text">Operations Manager</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="../assets/images/team3.jpg" class="card-img-top" alt="Team Member">
                    <div class="card-body">
                        <h5 class="card-title">Ali Khan</h5>
                        <p class="card-text">Volunteer Coordinator</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
