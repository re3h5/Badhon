<?php require_once '../includes/config.php'; ?>
<?php include '../includes/header.php'; ?>

<?php
// Fetch feedback data
$feedback_list = [];
try {
    $stmt = $conn->prepare("SELECT * FROM feedback ORDER BY created_at DESC");
    $stmt->execute();
    $feedback_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching feedback: " . $e->getMessage());
}
?>

<div class="container my-5">
    <h1 class="text-center">Feedback Management</h1>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Submitted At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($feedback_list as $feedback): ?>
                    <tr>
                        <td><?php echo $feedback['id']; ?></td>
                        <td><?php echo htmlspecialchars($feedback['name']); ?></td>
                        <td><?php echo htmlspecialchars($feedback['email']); ?></td>
                        <td><?php echo htmlspecialchars($feedback['message']); ?></td>
                        <td><?php echo $feedback['created_at']; ?></td>
                        <td>
                            <form method="POST" action="delete_feedback.php" style="display:inline;">
                                <input type="hidden" name="id" value="<?php echo $feedback['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
