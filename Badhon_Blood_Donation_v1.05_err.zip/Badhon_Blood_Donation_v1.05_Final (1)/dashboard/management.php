<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Management') {
    header('Location: ../pages/shared_login.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Management Dashboard</h1>
    <div class="row text-center">
        <div class="col-md-4">
            <a href="logs.php" class="btn btn-outline-primary btn-lg w-100">View Logs</a>
        </div>
        <div class="col-md-4">
            <a href="analytics.php" class="btn btn-outline-success btn-lg w-100">View Analytics</a>
        </div>
        <div class="col-md-4">
            <a href="role_management.php" class="btn btn-outline-danger btn-lg w-100">Role Management</a>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
