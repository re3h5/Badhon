<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: ../pages/shared_login.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Admin Dashboard</h1>
    <div class="row text-center">
        <div class="col-md-6">
            <a href="volunteer_management.php" class="btn btn-outline-primary btn-lg w-100">Manage Volunteers</a>
        </div>
        <div class="col-md-6">
            <a href="logs.php" class="btn btn-outline-success btn-lg w-100">View Logs</a>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
