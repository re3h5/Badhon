<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Fetch Role
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $name = htmlspecialchars($_POST['name']);
    $blood_group = $_POST['blood_group'];
    $contact = htmlspecialchars($_POST['contact']);
    $location = htmlspecialchars($_POST['location']);
    $message = htmlspecialchars($_POST['message']);

    try {
        $stmt = $conn->prepare("INSERT INTO emergency_requests (name, blood_group, contact, location, message, status) VALUES (:name, :blood_group, :contact, :location, :message, 'Pending')");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':blood_group', $blood_group);
        $stmt->bindParam(':contact', $contact);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':message', $message);
        $stmt->execute();
        $success_message = "Your emergency request has been submitted successfully!";
    } catch (PDOException $e) {
        $error_message = "Error submitting your request: " . $e->getMessage();
    }
}

// Fetch Requests
$requests = [];
try {
    if (in_array($role, ['Admin', 'Management'])) {
        // Fetch all requests for Admin/Management
        $stmt = $conn->prepare("SELECT * FROM emergency_requests");
    } else {
        // Fetch only user's requests
        $stmt = $conn->prepare("SELECT * FROM emergency_requests WHERE contact = (SELECT contact FROM users WHERE id = :user_id)");
        $stmt->bindParam(':user_id', $user_id);
    }
    $stmt->execute();
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching requests: " . $e->getMessage());
}

// Handle Status Update (For Admin/Management)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status']) && in_array($role, ['Admin', 'Management'])) {
    $request_id = intval($_POST['request_id']);
    $new_status = $_POST['status'];

    try {
        $stmt = $conn->prepare("UPDATE emergency_requests SET status = :status WHERE id = :id");
        $stmt->bindParam(':status', $new_status);
        $stmt->bindParam(':id', $request_id);
        $stmt->execute();
        header('Location: emergency_requests.php');
        exit();
    } catch (PDOException $e) {
        $error_message = "Error updating status: " . $e->getMessage();
    }
}
?>

<div class="container my-5">
    <h1 class="text-center">Emergency Requests</h1>

    <!-- Request Form -->
    <div class="mb-4">
        <h3>Submit an Emergency Request</h3>
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php elseif (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Your Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="blood_group" class="form-label">Blood Group</label>
                <select name="blood_group" id="blood_group" class="form-select" required>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="contact" class="form-label">Contact</label>
                <input type="text" name="contact" id="contact" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" name="location" id="location" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea name="message" id="message" class="form-control" required></textarea>
            </div>
            <button type="submit" name="submit_request" class="btn btn-primary">Submit Request</button>
        </form>
    </div>

    <!-- Requests List -->
    <h3>Emergency Requests</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Name</th>
                    <th>Blood Group</th>
                    <th>Contact</th>
                    <th>Location</th>
                    <th>Message</th>
                    <th>Status</th>
                    <?php if (in_array($role, ['Admin', 'Management'])): ?>
                        <th>Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($requests)): ?>
                    <tr>
                        <td colspan="<?php echo in_array($role, ['Admin', 'Management']) ? 7 : 6; ?>" class="text-center">No requests found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td><?php echo $request['name']; ?></td>
                            <td><?php echo $request['blood_group']; ?></td>
                            <td><?php echo $request['contact']; ?></td>
                            <td><?php echo $request['location']; ?></td>
                            <td><?php echo $request['message']; ?></td>
                            <td><?php echo $request['status']; ?></td>
                            <?php if (in_array($role, ['Admin', 'Management'])): ?>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                        <select name="status" class="form-select form-select-sm d-inline w-auto">
                                            <option value="Pending" <?php echo $request['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="Resolved" <?php echo $request['status'] === 'Resolved' ? 'selected' : ''; ?>>Resolved</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn btn-sm btn-success">Update</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
