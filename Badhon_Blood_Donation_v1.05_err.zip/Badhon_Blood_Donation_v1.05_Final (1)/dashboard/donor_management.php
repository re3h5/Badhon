<?php
require_once '../includes/config.php';
include '../includes/header.php';

// Session Check
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Volunteer') {
    header('Location: ../pages/shared_login.php');
    exit();
}

// Fetch all donors managed by this volunteer
$volunteer_id = $_SESSION['user_id'];
$donors = [];
try {
    $stmt = $conn->prepare("SELECT * FROM donors WHERE volunteer_id = :volunteer_id");
    $stmt->bindParam(':volunteer_id', $volunteer_id);
    $stmt->execute();
    $donors = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching donors: " . $e->getMessage());
}

// Handle Add, Update, or Delete Donor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    try {
        if ($action === 'add') {
            $stmt = $conn->prepare("INSERT INTO donors (name, blood_group, contact, address, dob, last_donation_date, eligibility_status, volunteer_id)
                                    VALUES (:name, :blood_group, :contact, :address, :dob, NULL, 1, :volunteer_id)");
            $stmt->bindParam(':name', $_POST['name']);
            $stmt->bindParam(':blood_group', $_POST['blood_group']);
            $stmt->bindParam(':contact', $_POST['contact']);
            $stmt->bindParam(':address', $_POST['address']);
            $stmt->bindParam(':dob', $_POST['dob']);
            $stmt->bindParam(':volunteer_id', $volunteer_id);
            $stmt->execute();
            $message = "Donor added successfully.";
        } elseif ($action === 'update') {
            $stmt = $conn->prepare("UPDATE donors SET name = :name, blood_group = :blood_group, contact = :contact, address = :address, dob = :dob WHERE id = :id");
            $stmt->bindParam(':name', $_POST['name']);
            $stmt->bindParam(':blood_group', $_POST['blood_group']);
            $stmt->bindParam(':contact', $_POST['contact']);
            $stmt->bindParam(':address', $_POST['address']);
            $stmt->bindParam(':dob', $_POST['dob']);
            $stmt->bindParam(':id', $_POST['donor_id']);
            $stmt->execute();
            $message = "Donor details updated successfully.";
        } elseif ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM donors WHERE id = :id");
            $stmt->bindParam(':id', $_POST['donor_id']);
            $stmt->execute();
            $message = "Donor deleted successfully.";
        }
    } catch (PDOException $e) {
        $error = "Error performing action: " . $e->getMessage();
    }
    header('Location: donor_management.php');
    exit();
}
?>

<div class="container my-5">
    <h1 class="text-center">Donor Management</h1>
    <?php if (!empty($message)): ?>
        <div class="alert alert-success"><?php echo $message; ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Add Donor Form -->
    <div class="mb-4">
        <h3>Add New Donor</h3>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="blood_group" class="form-label">Blood Group</label>
                <select name="blood_group" id="blood_group" class="form-select" required>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="contact" class="form-label">Contact</label>
                <input type="text" name="contact" id="contact" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <textarea name="address" id="address" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" name="dob" id="dob" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Donor</button>
        </form>
    </div>

    <!-- Donors List -->
    <h3>Manage Donors</h3>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Name</th>
                <th>Blood Group</th>
                <th>Contact</th>
                <th>Address</th>
                <th>Date of Birth</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($donors as $donor): ?>
                <tr>
                    <td><?php echo $donor['name']; ?></td>
                    <td><?php echo $donor['blood_group']; ?></td>
                    <td><?php echo $donor['contact']; ?></td>
                    <td><?php echo $donor['address']; ?></td>
                    <td><?php echo $donor['dob']; ?></td>
                    <td>
                        <!-- Update Donor Form -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="donor_id" value="<?php echo $donor['id']; ?>">
                            <button type="submit" class="btn btn-warning btn-sm">Edit</button>
                        </form>
                        <!-- Delete Donor Form -->
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="donor_id" value="<?php echo $donor['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this donor?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>
