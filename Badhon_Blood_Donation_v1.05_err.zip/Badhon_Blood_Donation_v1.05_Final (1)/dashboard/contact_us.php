<?php include '../includes/header.php'; ?>

<div class="container my-5">
    <h1 class="text-center">Contact Us</h1>
    <p class="text-center">
        Have questions or need support? Feel free to reach out to us through the form below or contact us directly.
    </p>

    <!-- Contact Form -->
    <div class="my-4">
        <h3>Send Us a Message</h3>
        <form method="POST" action="contact_form_handler.php">
            <div class="mb-3">
                <label for="name" class="form-label">Your Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Your Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea name="message" id="message" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Emergency Contacts -->
    <div class="my-4">
        <h3>Emergency Contacts</h3>
        <ul class="list-group">
            <li class="list-group-item">
                <strong>Blood Donation Helpline:</strong> +880123-456789
            </li>
            <li class="list-group-item">
                <strong>Emergency Services:</strong> +880987-654321
            </li>
            <li class="list-group-item">
                <strong>Email:</strong> support@badhonblood.org
            </li>
        </ul>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
