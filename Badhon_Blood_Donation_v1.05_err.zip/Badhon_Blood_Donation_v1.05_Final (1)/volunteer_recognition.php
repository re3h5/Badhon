
<?php
// Fetch volunteer recognition data from leaderboard_view
$stmt = $conn->prepare("
    SELECT * 
    FROM leaderboard_view 
    WHERE role = 'Volunteer'
    ORDER BY total_donations DESC
    LIMIT 5
");
$stmt->execute();
$top_volunteers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
