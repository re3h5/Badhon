
<?php
// Fetch donor history details
$stmt = $conn->prepare("SELECT * FROM user_activity_view WHERE donor_id = :donor_id");
$stmt->bindValue(':donor_id', $_GET['donor_id'], PDO::PARAM_INT);
$stmt->execute();
$donor_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
