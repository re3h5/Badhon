
<?php
// Fetch user and donor details for profile update
$stmt = $conn->prepare("
    SELECT u.name, u.email, d.blood_group, d.last_donation_date
    FROM users u
    LEFT JOIN donors d ON u.id = d.user_id
    WHERE u.id = :user_id
");
$stmt->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->execute();
$profile_data = $stmt->fetch(PDO::FETCH_ASSOC);
?>
